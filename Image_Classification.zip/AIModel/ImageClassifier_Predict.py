import numpy as np
import cv2 as cv
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras import datasets, layers, models
import pathlib
data_set_dir = "D:/ImageClassy/Datasets/"
data_dir = pathlib.Path(data_set_dir)   
image_count = len(list(data_dir.glob('*/*.jpg'))) 

batch_size = 32 
img_height = 200
img_width = 200

train_dataset = tf.keras.preprocessing.image_dataset_from_directory(
  data_dir,
  validation_split=0.2,  #sแบ่งข้อมูล เพื่อ training 80% และ validate 20%
  subset="training",
  seed=123,
  image_size=(img_height, img_width),
  batch_size=batch_size)

model = models.load_model('D:/ImageClassy/Image_ClassifierCustom.keras')

img = cv.imread("InputImage\Input.png")
img = cv.cvtColor(img,cv.COLOR_BGR2RGB)
img = cv.resize(img, (img_height, img_width))
plt.imshow(img,cmap=plt.cm.binary)

prediction= model.predict(np.array([img]))

index = np.argmax(prediction)

confidence = tf.nn.softmax(prediction[0])

class_names = sorted([item.name for item in data_dir.glob('*') if item.is_dir()])
print("\n".join([f"{class_names[i]}: {confidence[i] * 100:.2f}%" for i in range(len(class_names))]))
print(prediction)

plt.show()