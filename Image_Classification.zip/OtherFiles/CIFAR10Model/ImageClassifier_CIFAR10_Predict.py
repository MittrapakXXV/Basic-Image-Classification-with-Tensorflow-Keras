import numpy as np
import cv2 as cv
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras import datasets, layers, models
(train_images, train_labels), (test_images, test_labels) = datasets.cifar10.load_data()
train_images, test_images = train_images/255, test_images/255

Class_Names = ["Plane","Car","Bird","Cat","Deer","Dog","Frog","Horse","Ship","Truck"]

for i in range(15):
    plt.subplot(4,4,i+1)
    plt.xticks([])
    plt.yticks([])
    plt.imshow(train_images[i],cmap=plt.cm.binary)
    plt.xlabel(Class_Names[train_labels[i][0]])
plt.show()


train_images = train_images[:20000]
train_labels = train_labels[:20000]
test_images = test_images[:4000]
test_labels = test_labels[:4000]

model = models.load_model('Image_Classifier.keras')
img = cv.imread("InputImage\KANG.jpg")
img = cv.cvtColor(img,cv.COLOR_BGR2RGB)
img = cv.resize(img, (32, 32))
plt.imshow(img,cmap=plt.cm.binary)

prediction= model.predict(np.array([img]))

index = np.argmax(prediction)

confidence = tf.nn.softmax(prediction[0])
print("The Closest Match is {} {:.2f}%" .format(Class_Names[np.argmax(confidence)],100*np.max(confidence)))

plt.show()