import numpy as np
import cv2 as cv
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras import datasets, layers, models
import pathlib
import tkinter as tk
from tkinter import filedialog, Label, Button, Canvas, PhotoImage
from PIL import Image, ImageTk

# Load trained model
model = models.load_model('D:/ImageClassy/Image_ClassifierCustom.keras')

# Set image dimensions
img_height = 200
img_width = 200

def select_image():
    file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.png;*.jpg;*.jpeg;*.bmp;*.gif")])
    if not file_path:
        print("No file selected.")
        return
    
    img = cv.imread(file_path)
    img = cv.cvtColor(img, cv.COLOR_BGR2RGB)
    img = cv.resize(img, (img_height, img_width))
    
    img_pil = Image.fromarray(img)
    img_tk = ImageTk.PhotoImage(img_pil)
    canvas.create_image(0, 0, anchor=tk.NW, image=img_tk)
    canvas.image = img_tk
    
    prediction = model.predict(np.array([img]))
    confidence = tf.nn.softmax(prediction[0])
    
    # Load class names from dataset
    data_set_dir = "D:/ImageClassy/Datasets/"
    data_dir = pathlib.Path(data_set_dir)
    class_names = sorted([item.name for item in data_dir.glob('*') if item.is_dir()])
    
    result_text.set("Predictions:")
    result_details.set("\n".join([f"{class_names[i]}: {confidence[i] * 100:.2f}%" for i in range(len(class_names))]))

# Create GUI window
root = tk.Tk()
root.title("Image Classifier")
root.geometry("500x600")

result_text = tk.StringVar()
result_text.set("Select an image to classify")

result_details = tk.StringVar()

label = Label(root, textvariable=result_text, font=("Arial", 12))
label.pack()

canvas = Canvas(root, width=img_width, height=img_height)
canvas.pack()

label_details = Label(root, textvariable=result_details, font=("Arial", 10), justify=tk.LEFT)
label_details.pack()

btn_select = Button(root, text="Select Image", command=select_image)
btn_select.pack()

root.mainloop()
