import numpy as np
import cv2 as cv
import matplotlib.pyplot as plt
import tensorflow as tf
import os
from tensorflow.keras import datasets, layers, models
(train_images, train_labels), (test_images, test_labels) = datasets.cifar10.load_data()
train_images, test_images = train_images/255, test_images/255

Class_Names = ["Plane","Car","Bird","Cat","Deer","Dog","Frog","Horse","Ship","Truck"]
if (os.path.exists('Image_Classifier.keras') != True) :
    #ลดจำนวนข้อมูลให้น้อยลงเพื่อการ Train ที่รวดเร็ว
    train_images = train_images[:20000]
    train_labels = train_labels[:20000]
    test_images = test_images[:4000]
    test_labels = test_labels[:4000]
    
    model = models.Sequential()  #ใช้ model แบบง่าย มีเพียง 1 input และ 1 output
    model.add(layers.Conv2D(32,(3,3),activation='relu',input_shape=(32,32,3))) 
     #ใช้ Filter แบบ 3x3, 32 ตัว     โดยรับเข้าข้อมูลภาพขนาด  32x32 pixels
    model.add(layers.MaxPooling2D((2,2)))   #ใช้ Max Pooling แบบ 2x2
    model.add(layers.Conv2D(64,(3,3),activation='relu'))  #ใช้ Filter แบบ 3x3, 64 ตัว
    model.add(layers.MaxPooling2D((2,2)))   #ใช้ Max Pooling แบบ 2x2
    model.add(layers.Conv2D(64,(3,3),activation='relu'))    #ใช้ Filter แบบ 3x3, 64 ตัว
    model.add(layers.Flatten())                  #ปรับค่าเป็น 1 มิติ
    model.add(layers.Dense(128,activation='relu'))  #ชั้น Fully Connected    มี 128 neurons
    model.add(layers.Dense(10,activation='softmax'))  #Output มีจำนวน neuron ตามจำนวน class
    model.compile(optimizer='adam',loss='sparse_categorical_crossentropy',metrics=['accuracy'])
    #ใช้ optimizer และ loss function                #Train 10 Epochs
    model.fit(train_images,train_labels, epochs=10, validation_data=(test_images,test_labels))
    loss, acc = model.evaluate(test_images,test_labels)    
    print(f"Loss: {loss}")
    print(f"Acc: {acc}")
    model.save("Image_Classifier.keras")

    
    
model = models.load_model('Image_Classifier.keras')
img = cv.imread("InputImage\Input.jpg")
img = cv.cvtColor(img,cv.COLOR_BGR2RGB)
img = cv.resize(img, (32, 32))
plt.imshow(img,cmap=plt.cm.binary)

prediction= model.predict(np.array([img]))

index = np.argmax(prediction)

confidence = tf.nn.softmax(prediction[0])
print("The Closest Match is {} {:.2f}%" .format(Class_Names[np.argmax(confidence)],100*np.max(confidence)))

plt.show()