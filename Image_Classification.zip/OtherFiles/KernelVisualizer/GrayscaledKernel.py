import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load your custom image (grayscale for simplicity)
image_path = "InputImage\Input.png"  # Replace with your image path
image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

# Display the original image
plt.subplot(1, 2, 1)
plt.imshow(image, cmap='gray')
plt.title("Original Image")
plt.axis("off")

# Define your custom kernel (e.g., a sharpening kernel)
kernel = np.array([
   [0, -5, 0],
    [-1, 5, -1],
    [0, -1, 0]
], dtype=np.float32)

# Apply the kernel to the image
convolved_image = cv2.filter2D(image, -1, kernel)

# Apply stride by manually sub-sampling
stride = 1  # Define the stride
processed_image = convolved_image[::stride, ::stride]

# Display the processed image with stride
plt.subplot(1, 2, 2)
plt.imshow(processed_image, cmap='gray')
plt.title(f"Processed Image (Stride={stride})")
plt.axis("off")

# Show the results
plt.tight_layout()
plt.show()