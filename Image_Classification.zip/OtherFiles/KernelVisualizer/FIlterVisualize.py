import tensorflow as tf
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt

# Ensure compatibility with TensorFlow 1.x
tf.compat.v1.disable_eager_execution()

# Load an image from a folder (change 'image.jpg' to your actual image path)
image_path = "InputImage\Input1.png"
image = Image.open(image_path).convert("L")  # Convert to grayscale
image = np.array(image, dtype=np.float32)  # Convert to NumPy array

# Normalize and reshape image for TensorFlow (batch_size=1, height, width, channels=1)
image = image / 255.0  # Normalize pixel values (optional)
image = image.reshape(1, image.shape[0], image.shape[1], 1)

# Define a 3x3 edge detection filter (Sobel filter)
filter_values = np.array([[[0, -1, 0],
                           [-1,  5, -1],
                           [0, 5, 0]]], dtype=np.float32)

# Reshape to (height, width, in_channels, out_channels)
conv_filter = filter_values.reshape(3, 3, 1, 1)

# Define TensorFlow placeholders and convolution operation
image_tensor = tf.compat.v1.placeholder(tf.float32, shape=image.shape)
filter_tensor = tf.constant(conv_filter, dtype=tf.float32)

conv_result = tf.nn.conv2d(image_tensor, filter_tensor, strides=[1, 1, 1, 1], padding="SAME")

# Run the session
with tf.compat.v1.Session() as sess:
    result = sess.run(conv_result, feed_dict={image_tensor: image})

# Remove batch and channel dimensions for visualization
result = result[0, :, :, 0]

# Display the original and filtered images
plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.imshow(image[0, :, :, 0], cmap="gray")
plt.title("Original Image")

plt.subplot(1, 2, 2)
plt.imshow(result, cmap="gray")
plt.title("Filtered Image")

plt.show()
