import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load your custom image in color
image_path = "InputImage\KANG.jpg"  # Replace with your image path
image = cv2.imread(image_path)  # Default loads a color image (BGR format)

# Convert BGR to RGB for proper display with matplotlib
image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

# Display the original image
plt.subplot(1, 2, 1)
plt.imshow(image_rgb)
plt.title("Original Image")
plt.axis("off")

# Define your custom kernel (e.g., a sharpening kernel)
kernel = np.array([
     [0, -1, 0],
    [-1, 5, -1],
    [0, -1, 0]
], dtype=np.float32)


padding_size = kernel.shape[0] // 2
image_padded = cv2.copyMakeBorder(image, padding_size, padding_size, padding_size, padding_size, cv2.BORDER_CONSTANT, value=(0, 0, 0))

# Apply the kernel to each channel individually
processed_image = np.zeros_like(image, dtype=np.uint8)
for i in range(3):  # Loop through the R, G, B channels
    processed_image[:, :, i] = cv2.filter2D(image[:, :, i], -1, kernel)

# Convert BGR to RGB for proper display with matplotlib
processed_image_rgb = cv2.cvtColor(processed_image, cv2.COLOR_BGR2RGB)

# Display the processed image
plt.subplot(1, 2, 2)
plt.imshow(processed_image_rgb)
plt.title("Processed Image (Color)")
plt.axis("off")

# Show the results
plt.tight_layout()
plt.show()
