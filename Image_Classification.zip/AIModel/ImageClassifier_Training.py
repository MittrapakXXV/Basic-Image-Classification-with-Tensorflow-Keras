import numpy as np
import cv2 as cv
import matplotlib.pyplot as plt
import tensorflow as tf
import pathlib
from tensorflow.keras import datasets, layers, models

data_set_dir = "D:/ImageClassy/Datasets/"
data_dir = pathlib.Path(data_set_dir)   
image_count = len(list(data_dir.glob('*/*.jpg'))) 
  

batch_size = 15 
img_height = 200
img_width = 200

train_dataset = tf.keras.preprocessing.image_dataset_from_directory(
  data_dir,
  validation_split=0.2,  #sแบ่งข้อมูล เพื่อ training 80% และ validate 20%
  subset="training",
  seed=123,
  image_size=(img_height, img_width),
  batch_size=batch_size)
test_dataset = tf.keras.preprocessing.image_dataset_from_directory(
  data_dir,
  validation_split=0.2,
  subset="validation",
  seed=123,
  image_size=(img_height, img_width),
  batch_size=batch_size)


Class_Names = train_dataset.class_names
print(Class_Names)


for image, label in train_dataset.take(1):
    for i in range(9):
        plt.subplot(3,3,i+1)
        plt.xticks([])
        plt.yticks([])
        plt.imshow(image[i].numpy().astype("uint8"))
        plt.xlabel(Class_Names[label[i]])
plt.show()


num_classes = 4
epochs= 15


model = models.Sequential()     # 1 Input  1 Output
model.add(layers.Input(shape=(img_height, img_width, 3)))
model.add(layers.Rescaling(1./255))  # Normalization ([0-255] --> [0-1])
model.add(layers.Conv2D(16, 3, padding='same', activation='relu'))
model.add(layers.MaxPooling2D())  # Default_Size = 2x2 , Stride = 2
model.add(layers.Conv2D(32, 3, padding='same', activation='relu'))
model.add(layers.MaxPooling2D())
model.add(layers.Conv2D(64, 3, padding='same', activation='relu'))
model.add(layers.MaxPooling2D())
model.add(layers.Flatten())    

model.add(layers.Dense(128, activation='relu'))  
model.add(layers.Dense(num_classes))
model.summary() 
model.compile(optimizer='adam',loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),metrics=['accuracy'])
model.fit(train_dataset, epochs=15, validation_data=test_dataset)


model.save("Image_ClassifierCustom.keras")

