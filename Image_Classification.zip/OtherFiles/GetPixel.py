import numpy as np
from PIL import Image
import pyperclip

def convert_png_to_pixel_array(png_path):
    # Open the image and convert to RGBA (if it's not already in RGBA)
    img = Image.open(png_path).convert('RGBA')
    
    # Convert image to numpy array (height, width, 4)
    pixel_data = np.array(img)
    
    return pixel_data

def array_to_lua_dict(pixel_data):
    lua_dict = ""
    pixel_count = 0
    for row in pixel_data:
        for pixel in row:
            lua_dict += f"[{pixel_count}]={{" + ",".join(map(str, pixel)) + "},"
            pixel_count += 1
    # Removing the last comma
    lua_dict = lua_dict.rstrip(",")
    
    # Wrap with Lua table syntax
    return f"{{{lua_dict}}}"

def copy_to_clipboard(lua_dict):
    pyperclip.copy(lua_dict)

# Example usage
png_path = 'Money.png'  # Replace with your PNG file path
pixel_data = convert_png_to_pixel_array(png_path)
lua_dict = array_to_lua_dict(pixel_data)
copy_to_clipboard(lua_dict)
print("Lua dictionary has been copied to the clipboard!")
