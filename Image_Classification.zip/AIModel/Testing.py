import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing import image
from tensorflow.keras import layers, models

# Load the image from file

x = 16
y = 16

img_path = 'InputImage\Input.png'  # Change this to your image file path
img = image.load_img(img_path, target_size=(x, y),color_mode='grayscale')  # Resize to 32x32

img_array = image.img_to_array(img)
img_array = np.expand_dims(img_array, axis=0) 
img_array = img_array / 255.0


model = models.Sequential()
model.add(layers.InputLayer(input_shape=(x, y, 1)))  
model.add(layers.Conv2D(3, (3, 3),activation="relu" , padding='same'))

conv_output = model.predict(img_array)

pooling_layer = layers.AveragePooling2D(pool_size=(2, 2), padding='same')  # 2x2 pooling with same padding
relued_output = pooling_layer(conv_output)





plt.figure(figsize=(15, 15))




# Original image
plt.subplot(2, 4, 1)
plt.imshow(img,cmap="gray")

plt.axis('off')

for i in range(x):
    for j in range(y):
        pixel_value = img_array[0, i, j]
        plt.text(j, i, f'{(pixel_value * 255).astype(int)}', ha='center', va='center', color='red', fontsize=8)




for i in range(3):
    plt.subplot(2, 4, i + 2)
    ax = plt.gca()
    feature_map = conv_output[0, :, :, i]
    cax = ax.imshow(feature_map, cmap='gray')
    plt.title(f"Filter {i+1}")
    plt.axis('off')

    for j in range(feature_map.shape[0]):
        for k in range(feature_map.shape[1]):
            ax.text(k, j, f'{(feature_map[j, k]*255):.0f}', ha='center', va='center', color='red', fontsize=9)


for i in range(3):  
    plt.subplot(2, 4, i + 5)
    ax2 = plt.gca()
    feature_map2 = relued_output[0, :, :, i]
    cax2 = ax2.imshow(feature_map2, cmap='gray')
    plt.title(f"Filter {i+1}")
    plt.axis('off')

    for j in range(feature_map2.shape[0]):
        for k in range(feature_map2.shape[1]):
            ax2.text(k, j, f'{(feature_map2[j, k]*255):.0f}', ha='center', va='center', color='red', fontsize=9)


plt.tight_layout()
plt.show()



